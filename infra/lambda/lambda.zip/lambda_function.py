import boto3
import json

def lambda_handler(event, context):
    client = boto3.client('glue')

    response = client.start_job_run(JobName='bovespa')

    return {
        'statusCode': 200,
        'body': json.dumps('Glue Job iniciado com sucesso!')
    }
